import React from 'react'
function Form (){
    return(
        <div>
           <h1>Form</h1>
        </div>
    )
}
export default Form